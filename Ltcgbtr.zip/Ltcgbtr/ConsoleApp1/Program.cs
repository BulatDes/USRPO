﻿/*int first,second;
first = readInt("Введите первое число");
second = readInt("Введите второе число");
int readInt(string message)
{
    int result;
    bool success = false;
    do
    {
        Console.WriteLine(message);
        success = int.TryParse(Console.ReadLine(), out result);
    } while (!success);
    return result;
}
Console.WriteLine($"{first}+{second}={first+second}");

int power(int a,int b)
{
    int result=1;
    for (int i = 1; i <= b; i++)
    {
        result *= a;
    }
    return result;
}

int power2 (int a, int b) =>
    b == 0 ? 1 : a * power2(a, b - 1);
Console.WriteLine($"{first}^{second}={power2(first,second)}");*/


Console.WriteLine("Введите сумму которую хотите разменять");
int sum = int.Parse(Console.ReadLine());
int[] mas = { 5000,2000,1000,500,200,100,50,10,5,2,1};
string res="";
bool success = false;
int countcup = 0;
for (int i = 0; i < mas.Length && sum > 0; i++)
{
    int count = sum / mas[i];
    if (count == 0)
        continue;
    sum = sum % mas[i];
    Console.WriteLine($"{mas[i]} x {count}");
}
/*do
{
    for (int j = 0; j < mas.Length; j++)
    {
        if (mas[j] <= sum)
        {  
                sum = sum - mas[j];
                countcup++;
            res += $"{mas[j]},";
            break;
        }
    }

    if (sum == 0)
        success = true;
} while (!success);*/
//Console.WriteLine($"Мы разменяли {countcup} купюр с номиналами:\n {res}");
