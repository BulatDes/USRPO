﻿using System;

namespace HeroVsMonster.Classes
{
    /// <summary>
    /// Монстр. Его нужно побеждать. Имеет 1 зелье.
    /// Умеет бить и больно бить.
    /// </summary>
    public class Monster : Actor
    {
        public Monster(string name, int maximumHp, int damage)
            : base(name, maximumHp, damage)
        {
            // вызывается конструктор базового класса, это хорошо
            // однако, у мостра при создании должно быть одно зелье
        }


        /// <summary>
        /// Бьет врага кулаком или иными частями тела. Наносит
        /// базовый урон
        /// </summary>
        /// <param name="enemy">Противник, который хочет победить монстра</param>
        public void Punch(Actor enemy)
        {
            throw new NotImplementedException("Не реализовано");
        }

        /// <summary>
        /// Очень больно бьет врага кулаком или иными частями тела. Наносит
        /// пятикратный урон.
        /// </summary>
        /// <param name="enemy">Противник, который хочет победить монстра</param>
        public void MegaPunch(Actor enemy)
        {
            throw new NotImplementedException("Не реализовано");
        }

        /// <summary>
        /// Боевой крик монстра! ЪУЪ!!!
        /// </summary>
        /// <returns>Возвращает строку, соответствующую боевому крику</returns>
        public override string Roar()
        {
            return base.Roar();
        }


    }
}
