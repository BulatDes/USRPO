﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeroVsMonster.Classes
{
    /// <summary>
    /// Герой!
    /// Имеет два зелья. Может носить оружие. 
    /// Имеет способность, позволяющую добить противника, нанеся 
    /// десятикратный урон.
    /// </summary>
    public class Hero : Actor
    {
        /// <summary>
        /// Оружие, которое использует герой для победы.
        /// Если null, то герой бьет своим базовым уроном.
        /// </summary>
        public Weapon HeroWeapon { get; set; }

        
        public Hero(string name, int maximumHp, int damage) 
            : base(name, maximumHp, damage)
        {
            // вызывается конструктор базового класса
            // однако, у героя должно быть 2 зелья
            Potions = 2;
        }

        /// <summary>
        /// Атакует врага. Если у героя есть оружие, то 
        /// наносится урон, равный урону оружия.
        /// Если оружия нет, то наносится базовый урон.
        /// </summary>
        /// <param name="enemy">Враг, которого нужно победить</param>
        public void Attack(Actor enemy)
        {
            if (!IsDead)
            {
                if (HeroWeapon == null)
                {
                    enemy.GetDamage(Damage);
                } else
                {
                    enemy.GetDamage(HeroWeapon.Damage);
                }
            }

        }

        /// <summary>
        /// Добивает врага. Если враг имеет 1/5 здоровья
        /// или менее, то наносит десятикратный урон.
        /// В противном случае наносит обычный урон.
        /// </summary>
        /// <param name="enemy"></param>
        public void Execute(Actor enemy)
        {
            if(enemy.Health <= enemy.MaximumHealth / 5)
            {
                if (HeroWeapon == null)
                    enemy.GetDamage(Damage * 10);
                 else
                    enemy.GetDamage(HeroWeapon.Damage * 10);
                
            } else
            {
                if (HeroWeapon == null)
                    enemy.GetDamage(Damage);
                else
                    enemy.GetDamage(HeroWeapon.Damage);
            }
        }

        /// <summary>
        /// Боевой крик героя! УУООООО!!!!
        /// </summary>
        /// <returns>Возвращает строку, соответствующую боевому крику</returns>
        public override string Roar()
        {
            return "УУООООО!!!!";
        }

    }
}
