﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HeroVsMonster.Classes
{
    /// <summary>
    /// Базовый класс для Hero и Monster
    /// </summary>
    public abstract class Actor
    {
        protected int MaxHp;
        protected int Hp;
        protected int Potions;
        /// <summary>
        /// true, если мертв
        /// </summary>
        public bool IsDead
        {
            get
            {
                return Hp <= 0;
            }
            
        }
        /// <summary>
        /// Имя персонажа
        /// </summary>
        public string Name { get; protected set; }
        /// <summary>
        /// Урон персонажа
        /// </summary>
        public int Damage { get; protected set; }

        

        public int Health 
        { 
            get
            {
                return Hp;
            }
        }
        public int MaximumHealth
        {
            get
            {
                return MaxHp;
            }
        }

        /// <summary>
        /// Конструктор класса Actor
        /// </summary>
        /// <param name="name">Имя персонажа</param>
        /// <param name="maximumHp">Максимальное здоровье</param>
        /// <param name="damage">Наносимый урон</param>
        public Actor(string name, int maximumHp, int damage)
        {
            // уже реализовано
            this.Name = name;
            this.Hp = this.MaxHp = maximumHp;
            this.Damage = damage;
            Potions = 0;
        }

        /// <summary>
        /// Позволяет получить урон и уменьшить здоровье.
        /// </summary>
        /// <param name="dmg">Полученный урон</param>
        public void GetDamage(int dmg)
        {
            Hp -= dmg;
            if (Hp < 0)
            {
                Hp = 0;
            }  
            
        }

        /// <summary>
        /// Позволяет использовать зелье, чтобы восстановить 1/5 от 
        /// максимальной жизни. Не может быть бесполезным при низком максимальном
        /// здоровье. Не может сделать здоровье больше, чем максимальное.
        /// Зелье при использовании будет потрачено.
        /// </summary>
        public void UsePotion()
        {
            if (!IsDead)
            {
                if (Potions != 0)
                {
                    if (MaxHp < 5)
                        Hp += 1;
                    else
                        Hp += MaxHp / 5;

                    if (Hp > MaxHp)
                        Hp = MaxHp;
                    Potions--;
                }
            }
        }


        /// <summary>
        /// Боевой крик персонажа
        /// </summary>
        /// <returns>Возвращает строку, соответствующую боевому крику</returns>
        public virtual string Roar()
        {
            return "Hello, World!";
        }
    }
}
