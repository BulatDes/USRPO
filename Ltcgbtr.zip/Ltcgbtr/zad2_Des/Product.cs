﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad2_Des
{
    public abstract class Product
    {
        public string Name { get; set; }
        protected decimal Base_Price { get; set; }
        public string Image { get; set; }

        public abstract decimal Price
        {
            get;set;
        }
    }

}
